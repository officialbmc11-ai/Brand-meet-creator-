export const COLORS = {
  bg: '#0B0B0B',
  bgAlt: '#111111',
  white: '#FFFFFF',
  electricBlue: '#3B82F6',
  neonCyan: '#22D3EE',
  premiumPurple: '#8B5CF6',
} as const;

export const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Creators', href: '#creators' },
  { label: 'Campaigns', href: '#campaigns' },
  { label: 'Contact', href: '#contact' },
] as const;

export const STATS = [
  { value: '500+', label: 'Tech Creators' },
  { value: '300+', label: 'Gaming Creators' },
  { value: '150+', label: 'AI Creators' },
  { value: '200+', label: 'UGC Campaigns' },
  { value: '1000+', label: 'Brand Collaborations' },
] as const;

export const SERVICES = [
  {
    title: 'Influencer Marketing',
    description: 'Strategic partnerships with creators who authentically represent your brand to engaged audiences.',
    icon: 'Users',
  },
  {
    title: 'UGC Content',
    description: 'User-generated content that builds trust and drives conversions through authentic storytelling.',
    icon: 'Video',
  },
  {
    title: 'Reel Promotions',
    description: 'Short-form video campaigns designed for maximum engagement and viral potential.',
    icon: 'Film',
  },
  {
    title: 'Tech Campaigns',
    description: 'Creator campaigns tailored for SaaS, dev tools, and technology products.',
    icon: 'Cpu',
  },
  {
    title: 'Gaming Promotions',
    description: 'Targeted campaigns across gaming communities, streamers, and esports audiences.',
    icon: 'Gamepad2',
  },
  {
    title: 'AI Startup Promotions',
    description: 'Specialized marketing for AI products, reaching early adopters and tech enthusiasts.',
    icon: 'Sparkles',
  },
  {
    title: 'Creator Collaborations',
    description: 'End-to-end collaboration management between brands and creators for lasting partnerships.',
    icon: 'Handshake',
  },
] as const;

export const WHY_CREATOR_MARKETING = [
  {
    stat: '92%',
    title: 'Trust Creators Over Ads',
    description: 'Gen-Z consumers trust creator recommendations significantly more than traditional advertising.',
  },
  {
    stat: '3.5x',
    title: 'Higher Engagement',
    description: 'Short-form creator content generates 3.5x more engagement than brand-produced content.',
  },
  {
    stat: '11x',
    title: 'Higher ROI',
    description: 'Creator-driven campaigns deliver 11x higher ROI compared to traditional digital advertising.',
  },
] as const;

export const CREATOR_CATEGORIES = [
  {
    title: 'Tech Creators',
    description: 'Developers, product reviewers, and tech educators with engaged professional audiences.',
    icon: 'Monitor',
  },
  {
    title: 'Gaming Creators',
    description: 'Streamers, esports athletes, and gaming content creators with loyal communities.',
    icon: 'Gamepad2',
  },
  {
    title: 'Lifestyle Creators',
    description: 'Lifestyle and culture creators who blend products into authentic daily content.',
    icon: 'Heart',
  },
  {
    title: 'AI Creators',
    description: 'AI researchers, educators, and enthusiasts at the forefront of the AI revolution.',
    icon: 'Brain',
  },
  {
    title: 'Regional Creators',
    description: 'Creators across regional markets delivering localized, culturally relevant content.',
    icon: 'Globe',
  },
] as const;

export const CAMPAIGN_TYPES = [
  {
    title: 'Setup Reels',
    description: 'Cinematic desk setup and workspace reveal content for tech brands.',
    tag: 'Tech',
  },
  {
    title: 'Aesthetic Product Videos',
    description: 'Premium visual storytelling that showcases products in their best light.',
    tag: 'Lifestyle',
  },
  {
    title: 'Unboxing Campaigns',
    description: 'First-impression unboxing content that drives curiosity and purchase intent.',
    tag: 'Product',
  },
  {
    title: 'Creator Reviews',
    description: 'In-depth, honest reviews from trusted creators that build brand credibility.',
    tag: 'Trust',
  },
  {
    title: 'Gaming Promotions',
    description: 'Live stream and video promotions reaching millions of gaming enthusiasts.',
    tag: 'Gaming',
  },
] as const;

export const WHY_BRANDS_CHOOSE_US = [
  {
    title: 'Startup-Friendly',
    description: 'Flexible packages designed for startups and growing brands with scalable budgets.',
    icon: 'Rocket',
  },
  {
    title: 'Modern Marketing',
    description: 'Creator-first approach that replaces outdated ad strategies with authentic influence.',
    icon: 'TrendingUp',
  },
  {
    title: 'Flexible Campaigns',
    description: 'Custom campaign structures that adapt to your goals, timeline, and audience.',
    icon: 'SlidersHorizontal',
  },
  {
    title: 'Creator-Driven Growth',
    description: 'Real creators, real audiences, real results — no bots, no fake engagement.',
    icon: 'Zap',
  },
  {
    title: 'Digital-First Execution',
    description: 'Built for the modern internet — fast, data-driven, and optimized for performance.',
    icon: 'Globe',
  },
  {
    title: 'Gen-Z Audience Understanding',
    description: 'Deep understanding of Gen-Z behavior, platforms, and content preferences.',
    icon: 'Target',
  },
] as const;
