import { motion } from 'framer-motion';
import { ArrowRight, Sparkles } from 'lucide-react';

function FloatingOrb({ className }: { className: string }) {
  return (
    <div className={`absolute rounded-full blur-[120px] opacity-30 ${className}`} />
  );
}

function GridPattern() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `linear-gradient(rgba(59,130,246,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(59,130,246,0.03) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />
    </div>
  );
}

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0B0B0B]">
      <GridPattern />

      <FloatingOrb className="w-[600px] h-[600px] bg-[#3B82F6] -top-40 -left-40 animate-pulse" />
      <FloatingOrb className="w-[500px] h-[500px] bg-[#22D3EE] top-1/2 right-0 translate-x-1/3 animate-pulse [animation-delay:2s]" />
      <FloatingOrb className="w-[400px] h-[400px] bg-[#8B5CF6] bottom-0 left-1/3 animate-pulse [animation-delay:4s]" />

      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0B0B0B]" />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#3B82F6]/20 bg-[#3B82F6]/5 text-[#3B82F6] text-sm mb-8"
        >
          <Sparkles size={14} />
          <span>Creator Economy Marketing</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15 }}
          className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-white leading-[1.05] tracking-tight"
        >
          Creator-Led Growth
          <br />
          <span className="bg-gradient-to-r from-[#3B82F6] via-[#22D3EE] to-[#8B5CF6] bg-clip-text text-transparent">
            For Modern Brands
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-6 text-lg sm:text-xl text-white/50 max-w-2xl mx-auto leading-relaxed"
        >
          Helping tech brands, startups, AI companies, and gaming brands grow
          through creator-led campaigns, influencer marketing, UGC content, and
          short-form promotions.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.45 }}
          className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href="#contact"
            className="group px-8 py-3.5 rounded-full bg-[#3B82F6] text-white font-medium text-sm hover:bg-[#3B82F6]/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(59,130,246,0.4)] flex items-center gap-2"
          >
            Let's Collaborate
            <ArrowRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
          </a>
          <a
            href="#services"
            className="px-8 py-3.5 rounded-full border border-white/10 text-white/70 font-medium text-sm hover:border-white/20 hover:text-white transition-all duration-300 hover:bg-white/5"
          >
            Explore Services
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-20 flex items-center justify-center gap-8 text-white/20 text-xs tracking-widest uppercase"
        >
          {['Tech Brands', 'Startups', 'AI Companies', 'Gaming Brands'].map((item) => (
            <span key={item} className="hidden sm:inline">{item}</span>
          ))}
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5, delay: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div className="w-5 h-8 rounded-full border border-white/20 flex items-start justify-center p-1">
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-1 h-1.5 rounded-full bg-white/40"
          />
        </div>
      </motion.div>
    </section>
  );
}
