import { motion } from 'framer-motion';
import {
  Users,
  Video,
  Film,
  Cpu,
  Gamepad2,
  Sparkles,
  Handshake,
} from 'lucide-react';
import { useInView } from '../hooks/useInView';
import { SERVICES } from '../lib/constants';

const ICON_MAP: Record<string, React.ElementType> = {
  Users,
  Video,
  Film,
  Cpu,
  Gamepad2,
  Sparkles,
  Handshake,
};

export default function Services() {
  const { ref, isInView } = useInView(0.1);

  return (
    <section id="services" className="relative py-32 bg-[#111111]">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B0B0B] via-transparent to-[#0B0B0B]" />
      <div className="relative max-w-7xl mx-auto px-6" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center max-w-2xl mx-auto"
        >
          <p className="text-sm text-[#22D3EE] font-medium tracking-widest uppercase mb-4">
            Services
          </p>
          <h2 className="text-4xl sm:text-5xl font-bold text-white leading-tight">
            What We
            <span className="bg-gradient-to-r from-[#22D3EE] to-[#3B82F6] bg-clip-text text-transparent">
              {' '}Deliver
            </span>
          </h2>
          <p className="mt-4 text-white/40 text-lg">
            End-to-end creator marketing services designed for modern brands.
          </p>
        </motion.div>

        <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {SERVICES.map((service, i) => {
            const Icon = ICON_MAP[service.icon] || Sparkles;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.08 * i }}
                className="group relative p-6 rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] hover:border-white/10 transition-all duration-500"
              >
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#3B82F6]/5 via-transparent to-[#22D3EE]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative">
                  <div className="w-10 h-10 rounded-xl bg-[#3B82F6]/10 flex items-center justify-center mb-4 group-hover:bg-[#3B82F6]/20 transition-colors duration-300">
                    <Icon size={20} className="text-[#3B82F6]" />
                  </div>
                  <h3 className="text-white font-semibold text-base mb-2">
                    {service.title}
                  </h3>
                  <p className="text-sm text-white/40 leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
