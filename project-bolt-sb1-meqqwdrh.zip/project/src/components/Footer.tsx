import { Instagram, Mail, ArrowUpRight } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative bg-[#0B0B0B] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <a href="#" className="text-white font-semibold text-lg tracking-tight">
              Brand<span className="text-[#3B82F6]">Meets</span>Creator
            </a>
            <p className="mt-4 text-sm text-white/40 leading-relaxed max-w-xs">
              A modern creator marketing network focused on creator-led growth for digital-first brands.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Quick Links</h4>
            <div className="flex flex-col gap-2.5">
              {['About', 'Services', 'Creators', 'Campaigns', 'Contact'].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  className="text-sm text-white/40 hover:text-white transition-colors duration-300"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Connect</h4>
            <div className="flex flex-col gap-3">
              <a
                href="https://instagram.com/brandmeetcreator"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-white/40 hover:text-white transition-colors duration-300"
              >
                <Instagram size={16} />
                @brandmeetcreator
                <ArrowUpRight size={12} />
              </a>
              <a
                href="mailto:hello@brandmeetscreator.com"
                className="flex items-center gap-2 text-sm text-white/40 hover:text-white transition-colors duration-300"
              >
                <Mail size={16} />
                hello@brandmeetscreator.com
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/30">
            &copy; {new Date().getFullYear()} Brand Meets Creator. All rights reserved.
          </p>
          <p className="text-xs text-white/30">
            Founded by <span className="text-white/50">Mayur Bhosale</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
