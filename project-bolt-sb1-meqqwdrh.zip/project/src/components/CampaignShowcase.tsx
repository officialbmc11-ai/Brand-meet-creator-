import { motion } from 'framer-motion';
import { Play, ExternalLink } from 'lucide-react';
import { useInView } from '../hooks/useInView';
import { CAMPAIGN_TYPES } from '../lib/constants';

const TAG_COLORS: Record<string, string> = {
  Tech: 'bg-[#3B82F6]/10 text-[#3B82F6]',
  Lifestyle: 'bg-[#8B5CF6]/10 text-[#8B5CF6]',
  Product: 'bg-[#22D3EE]/10 text-[#22D3EE]',
  Trust: 'bg-green-500/10 text-green-400',
  Gaming: 'bg-orange-500/10 text-orange-400',
};

export default function CampaignShowcase() {
  const { ref, isInView } = useInView(0.1);

  return (
    <section id="campaigns" className="relative py-32 bg-[#0B0B0B]">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center max-w-2xl mx-auto"
        >
          <p className="text-sm text-[#3B82F6] font-medium tracking-widest uppercase mb-4">
            Campaign Showcase
          </p>
          <h2 className="text-4xl sm:text-5xl font-bold text-white leading-tight">
            Campaigns That
            <span className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] bg-clip-text text-transparent">
              {' '}Convert
            </span>
          </h2>
          <p className="mt-4 text-white/40 text-lg">
            Premium creator campaigns designed for maximum impact and authentic engagement.
          </p>
        </motion.div>

        <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CAMPAIGN_TYPES.map((campaign, i) => (
            <motion.div
              key={campaign.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 * i }}
              className="group relative rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] hover:border-white/10 transition-all duration-500 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-[#3B82F6]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="relative h-44 bg-gradient-to-br from-white/[0.03] to-white/[0.01] flex items-center justify-center">
                <div className="w-14 h-14 rounded-full border border-white/10 bg-white/5 flex items-center justify-center group-hover:border-[#3B82F6]/30 group-hover:bg-[#3B82F6]/10 transition-all duration-500">
                  <Play size={20} className="text-white/30 group-hover:text-[#3B82F6] transition-colors duration-300 ml-0.5" />
                </div>
                <span className={`absolute top-4 left-4 px-2.5 py-1 rounded-full text-xs font-medium ${TAG_COLORS[campaign.tag] || 'bg-white/10 text-white/60'}`}>
                  {campaign.tag}
                </span>
              </div>

              <div className="relative p-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-white font-semibold text-base">
                    {campaign.title}
                  </h3>
                  <ExternalLink size={14} className="text-white/20 group-hover:text-[#3B82F6] transition-colors duration-300" />
                </div>
                <p className="mt-2 text-sm text-white/40 leading-relaxed">
                  {campaign.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
