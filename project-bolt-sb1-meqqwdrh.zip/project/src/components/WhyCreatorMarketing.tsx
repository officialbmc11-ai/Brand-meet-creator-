import { motion } from 'framer-motion';
import { useInView } from '../hooks/useInView';
import { WHY_CREATOR_MARKETING } from '../lib/constants';

export default function WhyCreatorMarketing() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section className="relative py-32 bg-[#0B0B0B]">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center max-w-2xl mx-auto"
        >
          <p className="text-sm text-[#8B5CF6] font-medium tracking-widest uppercase mb-4">
            Why Creator Marketing
          </p>
          <h2 className="text-4xl sm:text-5xl font-bold text-white leading-tight">
            The Future of
            <span className="bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] bg-clip-text text-transparent">
              {' '}Brand Growth
            </span>
          </h2>
          <p className="mt-4 text-white/40 text-lg">
            Creator marketing outperforms traditional advertising across every metric that matters.
          </p>
        </motion.div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          {WHY_CREATOR_MARKETING.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.15 * i }}
              className="group relative p-8 rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] hover:border-white/10 transition-all duration-500"
            >
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-b from-[#8B5CF6]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative">
                <p className="text-5xl sm:text-6xl font-bold bg-gradient-to-r from-[#8B5CF6] via-[#3B82F6] to-[#22D3EE] bg-clip-text text-transparent">
                  {item.stat}
                </p>
                <h3 className="mt-4 text-xl font-semibold text-white">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm text-white/40 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1, delay: 0.6 }}
          className="mt-16 relative p-8 rounded-2xl border border-white/5 bg-white/[0.02] overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-[#3B82F6]/5 via-[#22D3EE]/5 to-[#8B5CF6]/5" />
          <div className="relative flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-xl font-semibold text-white">
                Gen-Z trusts creators more than traditional ads
              </h3>
              <p className="mt-2 text-white/40 text-sm max-w-lg">
                Short-form content increases engagement. Creators drive authentic trust and conversions. The creator economy is the new advertising.
              </p>
            </div>
            <div className="flex items-center gap-3">
              {['#3B82F6', '#22D3EE', '#8B5CF6'].map((color, i) => (
                <div
                  key={i}
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
