import { motion } from 'framer-motion';
import { useInView } from '../hooks/useInView';
import { STATS } from '../lib/constants';

export default function About() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section id="about" className="relative py-32 bg-[#0B0B0B]">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="max-w-3xl"
        >
          <p className="text-sm text-[#3B82F6] font-medium tracking-widest uppercase mb-4">
            About Us
          </p>
          <h2 className="text-4xl sm:text-5xl font-bold text-white leading-tight">
            A Modern Creator
            <br />
            <span className="bg-gradient-to-r from-[#3B82F6] to-[#22D3EE] bg-clip-text text-transparent">
              Marketing Network
            </span>
          </h2>
          <p className="mt-6 text-white/50 text-lg leading-relaxed max-w-2xl">
            Brand Meets Creator is a creator-led marketing network built for
            digital-first brands. We connect modern companies with the right
            creators to drive authentic growth through influencer campaigns, UGC
            content, and short-form promotions.
          </p>
        </motion.div>

        <div className="mt-16 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {STATS.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 * i }}
              className="group relative p-6 rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] hover:border-white/10 transition-all duration-500"
            >
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-b from-[#3B82F6]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative">
                <p className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-[#3B82F6] to-[#22D3EE] bg-clip-text text-transparent">
                  {stat.value}
                </p>
                <p className="mt-2 text-sm text-white/40">{stat.label}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
