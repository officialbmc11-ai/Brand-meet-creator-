import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function CTA() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section id="contact" className="relative py-32 bg-[#0B0B0B] overflow-hidden">
      <div className="absolute w-[600px] h-[600px] rounded-full blur-[150px] bg-[#3B82F6]/15 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute w-[400px] h-[400px] rounded-full blur-[120px] bg-[#8B5CF6]/10 top-1/3 left-1/4" />
      <div className="absolute w-[300px] h-[300px] rounded-full blur-[100px] bg-[#22D3EE]/10 bottom-1/3 right-1/4" />

      <div className="relative max-w-4xl mx-auto px-6 text-center" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
        >
          <p className="text-sm text-[#3B82F6] font-medium tracking-widest uppercase mb-4">
            Start Today
          </p>
          <h2 className="text-5xl sm:text-6xl md:text-7xl font-bold text-white leading-tight">
            Let's Grow
            <br />
            <span className="bg-gradient-to-r from-[#3B82F6] via-[#22D3EE] to-[#8B5CF6] bg-clip-text text-transparent">
              Together
            </span>
          </h2>
          <p className="mt-6 text-lg text-white/50 max-w-xl mx-auto leading-relaxed">
            Build creator-led campaigns that actually connect with modern audiences.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href="mailto:hello@brandmeetscreator.com"
            className="group px-8 py-3.5 rounded-full bg-[#3B82F6] text-white font-medium text-sm hover:bg-[#3B82F6]/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(59,130,246,0.4)] flex items-center gap-2"
          >
            Start Collaboration
            <ArrowRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
          </a>
          <a
            href="mailto:hello@brandmeetscreator.com"
            className="px-8 py-3.5 rounded-full border border-white/10 text-white/70 font-medium text-sm hover:border-white/20 hover:text-white transition-all duration-300 hover:bg-white/5"
          >
            Contact Us
          </a>
        </motion.div>
      </div>
    </section>
  );
}
