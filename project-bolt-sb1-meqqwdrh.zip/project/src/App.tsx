import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import WhyCreatorMarketing from './components/WhyCreatorMarketing';
import CreatorCategories from './components/CreatorCategories';
import CampaignShowcase from './components/CampaignShowcase';
import WhyBrandsChooseUs from './components/WhyBrandsChooseUs';
import CTA from './components/CTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-[#0B0B0B] text-white antialiased">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <WhyCreatorMarketing />
      <CreatorCategories />
      <CampaignShowcase />
      <WhyBrandsChooseUs />
      <CTA />
      <Footer />
    </div>
  );
}

export default App;
